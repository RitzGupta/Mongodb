# DNS Route Backup and Status Code

This will allow you to get all the DNS from route-53 and also provide you status code of that URL.


**Step-1:** In order to make the code run smoothly, we need to install all the Python libraries.

`pip3 install -r requirements.txt`

**Step-2:** Run the `app.py` file for creating values files.  

CMD: `python3 app.py`   

It will ask you to input aws profile of Master Account. So input that. It will take sometime to get all the data.    

**Step-3:** Output file will be available in `files/ ` folder.



