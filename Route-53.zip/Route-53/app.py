import boto3
import time
import requests
from tqdm import tqdm
from openpyxl import Workbook

# Function to get the response status code of a URL
def get_response_status_code(url):
    try:
        response = requests.get('https://' + url, timeout=5)
        return response.status_code
    except requests.exceptions.RequestException as e:
        return None

# Function to store CNAME records to Excel
def store_cname_records_to_excel(profile_name):
    # Initialize the Route 53 client
    boto3.setup_default_session(profile_name=profile_name)
    client = boto3.client('route53')

    # Create a new workbook
    wb = Workbook()
    sheet = wb.active
    sheet.title = "CNAME Records"

    # Add headers to the Excel sheet
    headers = ["Hosted Zone", "Record Name", "Type", "Value", "Status Code"]
    sheet.append(headers)

    # Get hosted zones
    paginator = client.get_paginator('list_hosted_zones')
    for page in paginator.paginate():

        
        for hosted_zone in page['HostedZones']:
            zone_id = hosted_zone['Id'].split('/')[-1]
            zone_name = hosted_zone['Name']

            # Get records in the hosted zone
            paginator_records = client.get_paginator('list_resource_record_sets')
            for record_response in tqdm(paginator_records.paginate(HostedZoneId=zone_id)):
                for record in tqdm(record_response['ResourceRecordSets']):
                    if record['Type'] == 'CNAME':
                        record_name = record['Name']
                        record_type = record['Type']
                        values = [rr['Value'] for rr in record.get('ResourceRecords', [])]
                
                        # Get status code for the CNAME record
                        status_code = get_response_status_code(record_name)
                    
                        # Write data to the Excel sheet
                        sheet.append([zone_name, record_name, record_type, ", ".join(values), status_code])

    # Getting the local time in dd-mm-yy format
    time_stamp = time.strftime("%d-%m-%y", time.localtime())

    # Save the workbook to a file
    wb.save(f"files/dns_record_{time_stamp}.xlsx")
    print(f"CNAME records stored in dns_record_{time_stamp}.xlsx")

if __name__ == "__main__":
    # Input AWS profile
    profile_name = input("Enter AWS profile name: ")
    store_cname_records_to_excel(profile_name)
